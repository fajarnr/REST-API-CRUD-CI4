<?php
namespace App\Models;
use CodeIgniter\Model;

class M_Pegawai extends Model{
    protected $table = "users";
    protected $primaryKey = "id";
    protected $allowedFields = ['fullname','email','password'];

    protected $validationRules = [
        'fullname' => 'required',
        'email' => 'required|valid_email',
        'password' => 'required'
    ];
    protected $validationMassages = [
        'fullname' => [
            'required' => 'masukan nama'
        ],
        'email' => [
            'required' => 'masukan email',
            'valid_email' => 'email tidak valid'
        ],
        'password' => [
            'required' => 'masukan password'
        ]
    ];
}
?>